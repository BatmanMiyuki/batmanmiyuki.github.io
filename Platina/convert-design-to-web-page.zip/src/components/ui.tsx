import {
  useEffect,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";
import { cn } from "../utils/cn";

/* ----------------------------------------------------------------- hooks */

export function useInView<T extends HTMLElement>(threshold = 0.18) {
  const ref = useRef<T | null>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      setInView(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setInView(true);
        });
      },
      { threshold, rootMargin: "0px 0px -6% 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold]);

  return { ref, inView };
}

export function useScale<T extends HTMLElement>(designWidth: number) {
  const ref = useRef<T | null>(null);
  const [scale, setScale] = useState(1);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const update = () => setScale(el.clientWidth / designWidth);
    update();
    if (typeof ResizeObserver === "undefined") {
      window.addEventListener("resize", update);
      return () => window.removeEventListener("resize", update);
    }
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, [designWidth]);

  return { ref, scale };
}

/* ----------------------------------------------------------------- reveal */

export function Reveal({
  children,
  delay = 0,
  className,
  as: Tag = "div",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  as?: "div" | "section" | "header" | "footer" | "li";
}) {
  const { ref, inView } = useInView<HTMLDivElement>(0.12);
  return (
    <Tag
      // @ts-expect-error – generic element ref
      ref={ref}
      className={cn("reveal", inView && "is-in", className)}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </Tag>
  );
}

/* ----------------------------------------------------------------- atoms */

export function Card({
  children,
  className,
  style,
  interactive,
}: {
  children: ReactNode;
  className?: string;
  style?: CSSProperties;
  interactive?: boolean;
}) {
  return (
    <div
      style={style}
      className={cn(
        "rounded-[14px] border border-white/[0.07] bg-gradient-to-b from-[#0d1118] to-[#0a0d12]",
        interactive &&
          "transition-all duration-300 hover:border-white/20 hover:from-[#12171f] hover:to-[#0d1016]",
        className,
      )}
    >
      {children}
    </div>
  );
}

export function SectionLabel({
  children,
  action,
  className,
}: {
  children: ReactNode;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex items-baseline justify-between", className)}>
      <span className="text-[9.5px] font-semibold tracking-[0.11em] text-mut uppercase">
        {children}
      </span>
      {action}
    </div>
  );
}

export function ProgressBar({
  value,
  tone = "blue",
  animated = true,
  className,
  height = 6,
  delay = 0,
}: {
  value: number;
  tone?: "blue" | "violet";
  animated?: boolean;
  className?: string;
  height?: number;
  delay?: number;
}) {
  const { ref, inView } = useInView<HTMLDivElement>(0.3);
  const w = animated ? (inView ? value : 0) : value;
  return (
    <div
      ref={ref}
      className={cn("w-full overflow-hidden rounded-full bg-white/[0.09]", className)}
      style={{ height }}
    >
      <div
        className={cn(
          "bar-fill h-full rounded-full",
          tone === "violet"
            ? "bg-[linear-gradient(90deg,#7c5cff,#a78bfa)]"
            : "bg-[linear-gradient(90deg,#1e56d6,#4f8cff)]",
        )}
        style={{ width: `${w}%`, transitionDelay: `${delay}ms` }}
      />
    </div>
  );
}

export function Ring({
  value,
  size = 78,
  thickness = 7,
}: {
  value: number;
  size?: number;
  thickness?: number;
}) {
  const { ref, inView } = useInView<HTMLDivElement>(0.4);
  const r = (size - thickness) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div
      ref={ref}
      className="relative shrink-0"
      style={{ width: size, height: size }}
    >
      <svg width={size} height={size} className="-rotate-90">
        <defs>
          <linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#1e56d6" />
            <stop offset="60%" stopColor="#4f8cff" />
            <stop offset="100%" stopColor="#8ec9ff" />
          </linearGradient>
        </defs>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="rgba(255,255,255,0.09)"
          strokeWidth={thickness}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="url(#ringGrad)"
          strokeWidth={thickness}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={inView ? c - (c * value) / 100 : c}
          style={{
            transition: "stroke-dashoffset 1.6s cubic-bezier(0.16,1,0.3,1) 0.15s",
          }}
        />
      </svg>
      <span className="tnum absolute inset-0 flex items-center justify-center text-[21px] font-bold tracking-[-0.02em] text-white">
        {value}%
      </span>
    </div>
  );
}
