import { useEffect, useRef, type ReactNode } from "react";
import { cn } from "../utils/cn";
import {
  BatteryIcon,
  CellularIcon,
  GamepadTabIcon,
  PlayTabIcon,
  SettingsTabIcon,
  StatsTabIcon,
  WifiIcon,
} from "../lib/icons";
import type { ScreenId } from "../lib/data";
import { useScale } from "./ui";

export const PHONE_W = 360;
export const PHONE_H = 1024;

/* ------------------------------------------------------------- status bar */

function StatusBar() {
  return (
    <div className="absolute inset-x-0 top-0 z-30 flex h-[46px] shrink-0 items-center justify-between px-[24px] text-white">
      <span className="tnum text-[15px] font-semibold tracking-[-0.01em]">9:41</span>
      <div className="flex items-center gap-[6px]">
        <CellularIcon className="h-[11px] w-[18px]" />
        <WifiIcon className="h-[12px] w-[17px]" />
        <BatteryIcon className="h-[12px] w-[26px]" />
      </div>
    </div>
  );
}

/* --------------------------------------------------------------- tab bar */

const TABS: { id: ScreenId; label: string; Icon: typeof StatsTabIcon }[] = [
  { id: "stats", label: "Stats", Icon: StatsTabIcon },
  { id: "games", label: "Jeux", Icon: GamepadTabIcon },
  { id: "play", label: "Play", Icon: PlayTabIcon },
  { id: "settings", label: "Paramètres", Icon: SettingsTabIcon },
];

function TabBar({
  active,
  onNavigate,
}: {
  active: ScreenId;
  onNavigate: (id: ScreenId) => void;
}) {
  return (
    <nav className="absolute inset-x-0 bottom-0 z-30 border-t border-white/[0.06] bg-[#05070a]/95 pt-[11px] pb-[38px] backdrop-blur-xl">
      <ul className="flex items-start justify-around px-[6px]">
        {TABS.map(({ id, label, Icon }) => {
          const on = active === id;
          return (
            <li key={id} className="min-w-0">
              <button
                type="button"
                onClick={() => onNavigate(id)}
                aria-current={on ? "page" : undefined}
                aria-label={label}
                className={cn(
                  "group flex w-[70px] flex-col items-center gap-[5px] rounded-xl py-[3px] transition-colors duration-200",
                  on ? "text-brand-2" : "text-mut hover:text-white/75",
                )}
              >
                <span className="relative flex h-[22px] items-center justify-center">
                  <Icon
                    className={cn(
                      "h-[21px] w-[21px] transition-transform duration-300",
                      on ? "scale-100" : "scale-[0.96]",
                      "group-active:scale-90",
                    )}
                  />
                  {on && (
                    <span className="pointer-events-none absolute -inset-2 -z-10 rounded-full bg-brand/25 blur-[10px]" />
                  )}
                </span>
                <span
                  className={cn(
                    "text-[10px] leading-none transition-colors",
                    on ? "font-semibold" : "font-medium",
                  )}
                >
                  {label}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

/* ----------------------------------------------------------- phone frame */

export function PhoneFrame({
  active,
  onNavigate,
  children,
  className,
}: {
  active: ScreenId;
  onNavigate: (id: ScreenId) => void;
  children: ReactNode;
  className?: string;
}) {
  const { ref, scale } = useScale<HTMLDivElement>(PHONE_W);
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scroller.current) scroller.current.scrollTop = 0;
  }, [active]);

  return (
    <div
      ref={ref}
      className={cn("relative w-full select-none", className)}
      style={{ aspectRatio: `${PHONE_W} / ${PHONE_H}` }}
    >
      <div
        style={{
          width: PHONE_W,
          height: PHONE_H,
          transform: `scale(${scale})`,
          transformOrigin: "top left",
        }}
        className="absolute left-0 top-0"
      >
        <div className="relative h-full w-full rounded-[46px] bg-[#0a0a0c] p-[3px] shadow-[0_40px_90px_-30px_rgba(0,0,0,0.95),0_0_0_1px_rgba(255,255,255,0.06)]">
          {/* ambient edge light */}
          <div className="pointer-events-none absolute inset-0 rounded-[46px] bg-[linear-gradient(150deg,rgba(255,255,255,0.12),transparent_35%,transparent_65%,rgba(79,140,255,0.14))]" />
          <div className="relative h-full w-full overflow-hidden rounded-[43px] bg-black">
            <StatusBar />
            <div
              ref={scroller}
              className="no-bar absolute inset-x-0 top-[46px] bottom-[88px] overflow-y-auto overscroll-contain"
            >
              <div key={active} className="screen-in">
                {children}
              </div>
            </div>
            <TabBar active={active} onNavigate={onNavigate} />
          </div>
        </div>
      </div>
    </div>
  );
}
