import { Card, SectionLabel } from "../components/ui";
import {
  AppearanceIcon,
  BellSmallIcon,
  ChevronRight,
  CurrencyIcon,
  GlobeIcon,
  InfoIcon,
  LinkIcon,
  LockIcon,
  MailIcon,
  PaletteIcon,
  PowerIcon,
  SaveIcon,
  UploadIcon,
  UsersIcon,
} from "../lib/icons";
import { settingsGroups } from "../lib/data";

const ICONS = {
  users: UsersIcon,
  link: LinkIcon,
  lock: LockIcon,
  bell: BellSmallIcon,
  palette: PaletteIcon,
  globe: GlobeIcon,
  currency: CurrencyIcon,
  appearance: AppearanceIcon,
  upload: UploadIcon,
  save: SaveIcon,
  info: InfoIcon,
  mail: MailIcon,
} as const;

export default function SettingsScreen() {
  return (
    <div className="px-[18px] pb-[26px]">
      <header className="pt-[8px]">
        <h1 className="text-[27px] font-bold leading-none tracking-[-0.03em] text-white">
          Paramètres
        </h1>
      </header>

      {/* profile */}
      <Card interactive className="group mt-[18px] flex items-center gap-[13px] p-[11px]">
        <span className="relative h-[46px] w-[46px] shrink-0 overflow-hidden rounded-full ring-1 ring-white/15">
          <img
            src="/images/avatar.jpg"
            alt="Avatar de Batman Miyuki"
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
          <span className="absolute inset-0 rounded-full ring-1 ring-inset ring-white/10" />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[16px] font-bold leading-tight tracking-[-0.01em] text-white">
            Batman Miyuki
          </span>
          <span className="mt-[3px] block truncate text-[11.5px] leading-tight text-mut-2">
            @BatmanMiyuki
          </span>
        </span>
        <ChevronRight className="h-[15px] w-[15px] shrink-0 text-mut transition-transform duration-300 group-hover:translate-x-[2px] group-hover:text-white" />
      </Card>

      {settingsGroups.map((group) => (
        <section key={group.label}>
          <SectionLabel className="mt-[19px]">{group.label}</SectionLabel>
          <Card className="mt-[9px] overflow-hidden">
            <ul className="divide-y divide-white/[0.05]">
              {group.rows.map((row) => {
                const Icon = ICONS[row.icon];
                return (
                  <li key={row.title}>
                    <button
                      type="button"
                      className="group flex w-full items-center gap-[12px] px-[12px] py-[8px] text-left transition-colors hover:bg-white/[0.04]"
                    >
                      <span className="flex h-[28px] w-[28px] shrink-0 items-center justify-center rounded-[9px] border border-white/[0.07] bg-white/[0.05] text-white/80 transition-colors group-hover:border-brand/50 group-hover:text-brand-2">
                        <Icon className="h-[15px] w-[15px]" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[12.5px] font-semibold leading-tight text-white">
                          {row.title}
                        </span>
                        {row.sub && (
                          <span className="mt-[3px] block truncate text-[10px] leading-tight text-mut">
                            {row.sub}
                          </span>
                        )}
                      </span>
                      {row.value && (
                        <span className="shrink-0 text-[11px] text-mut-2">
                          {row.value}
                        </span>
                      )}
                      <ChevronRight className="h-[14px] w-[14px] shrink-0 text-mut transition-all duration-300 group-hover:translate-x-[2px] group-hover:text-white" />
                    </button>
                  </li>
                );
              })}
            </ul>
          </Card>
        </section>
      ))}

      <button
        type="button"
        className="group mt-[19px] flex h-[44px] w-full items-center justify-center gap-[8px] rounded-[12px] border border-[#e5484d]/30 bg-[#e5484d]/[0.10] text-[13px] font-semibold text-[#f2555a] transition-all duration-300 hover:border-[#e5484d]/60 hover:bg-[#e5484d]/[0.18] hover:text-white"
      >
        <PowerIcon className="h-[15px] w-[15px]" />
        Déconnexion
      </button>
    </div>
  );
}
