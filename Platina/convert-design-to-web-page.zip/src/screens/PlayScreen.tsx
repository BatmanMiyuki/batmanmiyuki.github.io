import { useState } from "react";
import { Card, SectionLabel, useInView } from "../components/ui";
import {
  CartIcon,
  ChevronDown,
  ChevronRight,
  GearIcon,
  PSPlusMark,
  PSStoreIcon,
  TrophyCup,
} from "../lib/icons";
import { weeklyHours } from "../lib/data";

const PLOT_H = 92;
const MAX_H = 8;

function Chart() {
  const { ref, inView } = useInView<HTMLDivElement>(0.25);
  const [hover, setHover] = useState<number | null>(null);
  const ticks = ["8h", "6h", "4h", "2h", "0h"];

  return (
    <div ref={ref} className="mt-[18px] flex gap-[8px]">
      <ul className="flex h-[92px] flex-col justify-between pt-[1px]">
        {ticks.map((t) => (
          <li key={t} className="tnum text-[8.5px] leading-none text-mut">
            {t}
          </li>
        ))}
      </ul>
      <div className="min-w-0 flex-1">
        <ul
          className="flex items-end justify-between gap-[9px]"
          style={{ height: PLOT_H }}
          onMouseLeave={() => setHover(null)}
        >
          {weeklyHours.map((d, i) => {
            const h = (d.value / MAX_H) * PLOT_H;
            const on = hover === i;
            return (
              <li
                key={d.day}
                className="group relative flex h-full flex-1 cursor-pointer items-end"
                onMouseEnter={() => setHover(i)}
              >
                <span
                  className="w-full rounded-t-[4px] bg-[linear-gradient(180deg,#5b95ff,#2563eb_55%,#1a48bd)] transition-all duration-700 ease-[cubic-bezier(0.16,1,0.3,1)]"
                  style={{
                    height: inView ? h : 0,
                    transitionDelay: `${i * 70}ms`,
                    boxShadow: on
                      ? "0 0 16px rgba(79,140,255,0.75)"
                      : "0 0 0 rgba(79,140,255,0)",
                  }}
                />
                <span
                  className="tnum pointer-events-none absolute -top-[2px] left-1/2 -translate-x-1/2 rounded-[4px] bg-white px-[4px] py-[1px] text-[8px] font-semibold leading-none text-black opacity-0 transition-opacity duration-200 group-hover:opacity-100"
                  style={{ whiteSpace: "nowrap" }}
                >
                  {d.value}h
                </span>
              </li>
            );
          })}
        </ul>
        <ul className="mt-[6px] flex justify-between gap-[9px]">
          {weeklyHours.map((d) => (
            <li
              key={d.day}
              className="flex-1 text-center text-[8.5px] leading-none text-mut"
            >
              {d.day}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default function PlayScreen() {
  return (
    <div className="relative px-[18px] pb-[26px]">
      {/* header */}
      <header className="relative z-10 pt-[8px]">
        <div className="flex items-start justify-between">
          <h1 className="text-[27px] font-bold leading-none tracking-[-0.03em] text-white">
            Play
          </h1>
          <button
            type="button"
            aria-label="Paramètres PlayStation"
            className="mt-[2px] text-white/90 transition-colors hover:text-brand-2"
          >
            <GearIcon className="h-[21px] w-[21px]" />
          </button>
        </div>
        <p className="mt-[6px] text-[11.5px] leading-none text-mut-2">
          Statistiques de la PlayStation
        </p>
      </header>

      {/* console art */}
      <div className="pointer-events-none absolute right-[10px] top-[16px] z-20 w-[126px]">
        <div className="absolute inset-x-[6px] top-[10px] h-[92px] rounded-full bg-[radial-gradient(circle,rgba(120,170,255,0.28),transparent_68%)] blur-[10px]" />
        <img
          src="/images/ps5.png"
          alt="Console PlayStation 5"
          className="relative w-full mix-blend-screen"
        />
      </div>

      {/* temps de jeu */}
      <SectionLabel className="mt-[20px]">Temps de jeu</SectionLabel>

      <div className="relative z-10 mt-[9px]">
        <Card
          className="p-[15px] pb-[16px]"
          style={{
            clipPath: "polygon(0 0, 60% 0, 100% 27%, 100% 100%, 0 100%)",
          }}
        >
        <div className="flex items-start justify-between pr-[6px]">
          <div>
            <div className="text-[11px] leading-none text-mut-2">
              Temps de jeu total
            </div>
            <div className="tnum mt-[5px] text-[27px] font-bold leading-none tracking-[-0.02em] text-white">
              1 248 h
            </div>
            <div className="mt-[6px] text-[11px] leading-none text-mut-2">
              Soit 52 jours
            </div>
          </div>
          <button
            type="button"
            className="mt-[48px] flex shrink-0 items-center gap-[4px] rounded-[7px] border border-white/[0.12] bg-white/[0.05] px-[8px] py-[5px] text-[10px] font-medium text-white/90 transition-colors hover:border-white/25 hover:bg-white/[0.1]"
          >
            7 derniers jours
            <ChevronDown className="h-[10px] w-[10px]" />
          </button>
        </div>
          <Chart />
        </Card>
        <svg
          aria-hidden
          className="pointer-events-none absolute inset-0 h-full w-full"
          viewBox="0 0 100 100"
          preserveAspectRatio="none"
        >
          <line
            x1="60"
            y1="0"
            x2="100"
            y2="27"
            stroke="rgba(255,255,255,0.14)"
            strokeWidth="1"
            vectorEffect="non-scaling-stroke"
          />
        </svg>
      </div>

      {/* mini stats */}
      <ul className="mt-[11px] grid grid-cols-[1fr_1fr_1.14fr] gap-[8px]">
        {[
          { label: "Sessions", value: "312", accent: false },
          { label: "Jeux différents", value: "58", accent: true },
          { label: "Jour le plus actif", value: "Vendredi", accent: false, small: true },
        ].map((s) => (
          <li key={s.label}>
            <Card interactive className="h-[70px] px-[11px] py-[11px]">
              <div
                className={
                  s.accent
                    ? "text-[10px] leading-tight text-brand-2"
                    : "text-[10px] leading-tight text-mut"
                }
              >
                {s.label}
              </div>
              <div
                className={
                  s.small
                    ? "mt-[9px] text-[14.5px] font-semibold leading-none text-white"
                    : "tnum mt-[11px] text-[20px] font-bold leading-none text-white"
                }
              >
                {s.value}
              </div>
            </Card>
          </li>
        ))}
      </ul>

      {/* dépenses */}
      <SectionLabel className="mt-[20px]">Dépenses</SectionLabel>
      <div className="mt-[9px] grid grid-cols-[1.72fr_1fr] gap-[9px]">
        <Card interactive className="relative overflow-hidden p-[13px]">
          <div className="text-[10.5px] leading-tight text-brand-2">
            Total dépensé sur le PS Store
          </div>
          <div className="tnum mt-[8px] text-[24px] font-bold leading-none tracking-[-0.02em] text-white">
            €1 248,75
          </div>
          <div className="mt-[8px] text-[10.5px] leading-none text-mut-2">
            Cette année : €623,40
          </div>
          <span className="absolute right-[12px] top-[13px] text-brand-2">
            <PSStoreIcon className="h-[26px] w-[26px]" />
          </span>
        </Card>
        <Card interactive className="p-[13px]">
          <div className="text-[10.5px] leading-tight text-brand-2">
            Transactions
          </div>
          <div className="tnum mt-[8px] text-[24px] font-bold leading-none text-white">
            96
          </div>
          <button
            type="button"
            className="mt-[9px] flex items-center gap-[2px] text-[10.5px] font-medium leading-none text-brand-2 transition-colors hover:text-white"
          >
            Voir l'historique
            <ChevronRight className="h-[9px] w-[9px]" />
          </button>
        </Card>
      </div>

      {/* abonnements */}
      <SectionLabel className="mt-[20px]">Abonnements</SectionLabel>
      <Card interactive className="group mt-[9px] flex items-center gap-[11px] p-[11px]">
        <span className="flex h-[36px] w-[36px] shrink-0 items-center justify-center rounded-[9px] border border-white/[0.08] bg-white/[0.05] text-mut-2">
          <svg viewBox="0 0 24 24" className="h-[17px] w-[17px]" fill="none">
            <path
              d="M3.5 8.5h17M4.5 5.5h15a1.4 1.4 0 0 1 1.4 1.4v10.2a1.4 1.4 0 0 1-1.4 1.4H4.5a1.4 1.4 0 0 1-1.4-1.4V6.9a1.4 1.4 0 0 1 1.4-1.4Z"
              stroke="currentColor"
              strokeWidth="1.5"
            />
            <path d="M6.6 14.4h4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[13px] font-semibold leading-tight text-white">
            PlayStation Plus Extra
          </span>
          <span className="mt-[4px] block truncate text-[11px] leading-tight text-mut-2">
            Prochain paiement : 14/08/2026
          </span>
        </span>
        <PSPlusMark className="h-[32px] w-[32px] shrink-0 drop-shadow-[0_3px_8px_rgba(240,169,12,0.35)] transition-transform duration-300 group-hover:scale-110" />
      </Card>

      {/* activité récente */}
      <SectionLabel className="mt-[20px]">Activité récente</SectionLabel>
      <div className="mt-[9px] space-y-[9px]">
        <Card interactive className="group flex items-center gap-[12px] p-[12px]">
          <span className="flex h-[40px] w-[40px] shrink-0 items-center justify-center rounded-full border border-white/[0.09] bg-white/[0.05] text-white/85">
            <CartIcon className="h-[18px] w-[18px]" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-[10px] leading-tight text-mut">Achat</span>
            <span className="mt-[3px] block truncate text-[12.5px] font-semibold leading-tight text-white">
              ELDEN RING Shadow of the Erdtree
            </span>
            <span className="mt-[3px] block text-[10px] leading-tight text-mut">
              Il y a 3 jours
            </span>
          </span>
          <span className="tnum shrink-0 text-[12px] font-medium text-white">
            − €39,99
          </span>
        </Card>

        <Card interactive className="group flex items-center gap-[12px] p-[12px]">
          <span className="relative h-[42px] w-[42px] shrink-0 overflow-hidden rounded-full ring-1 ring-white/10">
            <img
              src="/images/trophy-tile.jpg"
              alt=""
              loading="lazy"
              className="h-full w-full object-cover opacity-85 transition-transform duration-500 group-hover:scale-110"
            />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-[10px] leading-tight text-mut">
              Trophée obtenu
            </span>
            <span className="mt-[3px] block truncate text-[12.5px] font-semibold leading-tight text-white">
              Maître d'armes
            </span>
            <span className="mt-[2px] block truncate text-[11px] leading-tight text-mut-2">
              God of War Ragnarök
            </span>
            <span className="mt-[2px] block text-[10px] leading-tight text-mut">
              Il y a 1 jour
            </span>
          </span>
          <TrophyCup
            tone="gold"
            className="h-[28px] w-[28px] shrink-0 drop-shadow-[0_3px_8px_rgba(0,0,0,0.6)] transition-transform duration-300 group-hover:scale-110"
          />
        </Card>
      </div>
    </div>
  );
}
