import { Card, ProgressBar } from "../components/ui";
import {
  ChevronDown,
  CrownIcon,
  SearchIcon,
  SlidersIcon,
  TrophyCup,
} from "../lib/icons";
import { currentGames, platinized, type Game } from "../lib/data";

function PlatformBadge({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-[4px] border border-white/[0.09] bg-white/[0.04] px-[5px] py-[2px] text-[9px] font-medium leading-none tracking-[0.04em] text-mut-2">
      {children}
    </span>
  );
}

function Counts({ game }: { game: Game }) {
  const tones = ["plat", "gold", "silver", "bronze"] as const;
  return (
    <ul className="flex items-center gap-[14px]">
      {game.counts.map((n, i) => (
        <li key={i} className="flex items-center gap-[4px]">
          <TrophyCup tone={tones[i]} className="h-[13px] w-[13px]" />
          <span
            className="tnum text-[11px] font-semibold leading-none"
            style={{
              color:
                tones[i] === "plat"
                  ? "#dfe7f2"
                  : tones[i] === "gold"
                    ? "#e9b431"
                    : tones[i] === "silver"
                      ? "#c2c8d2"
                      : "#d9763a",
            }}
          >
            {n}
          </span>
        </li>
      ))}
    </ul>
  );
}

function GameCard({ game, index }: { game: Game; index: number }) {
  const done = game.progress === 100;
  return (
    <li>
      <Card
        interactive
        className="group p-[11px]"
        style={{ transitionDelay: `${index * 20}ms` }}
      >
        <div className="flex gap-[11px]">
          <div className="relative h-[70px] w-[70px] shrink-0 overflow-hidden rounded-[10px] ring-1 ring-white/10">
            <img
              src={game.cover}
              alt=""
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <span className="absolute inset-0 bg-[linear-gradient(160deg,rgba(255,255,255,0.14),transparent_45%)]" />
          </div>
          <div className="min-w-0 flex-1 pt-[3px]">
            <h3 className="truncate text-[14px] font-semibold leading-tight tracking-[-0.01em] text-white">
              {game.title}
            </h3>
            <div className="mt-[7px] flex items-center justify-between">
              <PlatformBadge>{game.platform}</PlatformBadge>
              <span className="tnum text-[12px] font-medium leading-none text-white/90">
                {game.progress}%
              </span>
            </div>
            <ProgressBar
              value={game.progress}
              tone={done ? "violet" : "blue"}
              height={3}
              className="mt-[10px]"
              delay={index * 90}
            />
            <div className="mt-[10px] flex items-center justify-between">
              <Counts game={game} />
              {game.date && (
                <span className="tnum text-[10px] leading-none text-mut">
                  {game.date}
                </span>
              )}
            </div>
          </div>
        </div>
      </Card>
    </li>
  );
}

export default function GamesScreen() {
  return (
    <div className="px-[18px] pb-[26px]">
      <header className="flex items-center justify-between pt-[8px]">
        <h1 className="text-[27px] font-bold leading-none tracking-[-0.03em] text-white">
          Jeux
        </h1>
        <div className="flex items-center gap-[16px] text-white">
          <button
            type="button"
            aria-label="Rechercher"
            className="transition-colors hover:text-brand-2"
          >
            <SearchIcon className="h-[20px] w-[20px]" />
          </button>
          <button
            type="button"
            aria-label="Filtrer"
            className="transition-colors hover:text-brand-2"
          >
            <SlidersIcon className="h-[20px] w-[20px]" />
          </button>
        </div>
      </header>

      {/* segmented */}
      <div className="mt-[22px] flex items-center justify-between">
        <button
          type="button"
          className="rounded-[11px] bg-brand px-[17px] py-[9px] text-[13px] font-semibold text-white shadow-[0_0_20px_-4px_rgba(47,107,255,0.9)] transition-all hover:bg-brand-2 hover:shadow-[0_0_26px_-2px_rgba(79,140,255,0.9)]"
        >
          En cours
        </button>
        <button
          type="button"
          className="text-[14px] font-medium text-white/85 transition-colors hover:text-white"
        >
          Platinés
        </button>
        <button
          type="button"
          className="tnum text-[14px] font-semibold text-white transition-colors hover:text-brand-2"
        >
          100%
        </button>
      </div>

      <ul className="mt-[16px] space-y-[11px]">
        {currentGames.map((g, i) => (
          <GameCard key={g.id} game={g} index={i} />
        ))}
      </ul>

      {/* platinés */}
      <div className="mt-[20px] flex items-center justify-between">
        <div className="flex items-center gap-[7px]">
          <CrownIcon className="h-[12px] w-[15px] text-[#7c8cff]" />
          <span className="text-[12px] font-bold tracking-[0.07em] text-[#7c8cff]">
            PLATINÉS (12)
          </span>
        </div>
        <button
          type="button"
          className="flex items-center gap-[4px] text-[11px] text-mut-2 transition-colors hover:text-white"
        >
          Trier par : Date
          <ChevronDown className="h-[11px] w-[11px]" />
        </button>
      </div>

      <ul className="mt-[12px] space-y-[11px]">
        {platinized.map((g, i) => (
          <GameCard key={g.id} game={g} index={i} />
        ))}
      </ul>

    </div>
  );
}
