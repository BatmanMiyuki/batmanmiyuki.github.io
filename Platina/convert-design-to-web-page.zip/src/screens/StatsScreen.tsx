import { Card, ProgressBar, Ring, SectionLabel } from "../components/ui";
import {
  BellIcon,
  ChevronRight,
  PlatinumBadge,
  PlatinaLogo,
  TrophyCup,
} from "../lib/icons";
import { recentTrophies } from "../lib/data";

const metals = [
  { tone: "plat", value: "34", label: "Platine" },
  { tone: "gold", value: "156", label: "Or" },
  { tone: "silver", value: "302", label: "Argent" },
  { tone: "bronze", value: "964", label: "Bronze" },
] as const;

const globalRows: { label: string; value: string; muted?: string }[] = [
  { label: "Jeux joués", value: "47" },
  { label: "Jeux platinés", value: "12" },
  { label: "Trophées obtenus", value: "1 456", muted: "/ 2 052" },
];

export default function StatsScreen() {
  return (
    <div className="px-[18px] pb-[26px]">
      {/* header */}
      <header className="flex items-start justify-between pt-[8px]">
        <div className="flex items-center gap-[10px]">
          <PlatinaLogo className="mt-[2px] h-[30px] w-[34px]" />
          <div>
            <h1 className="text-[24px] font-bold leading-[1.15] tracking-[-0.025em] text-white">
              Platina
            </h1>
            <p className="mt-[1px] text-[11px] leading-none text-mut-2">
              Tes trophées, ta légende.
            </p>
          </div>
        </div>
        <button
          type="button"
          aria-label="Notifications"
          className="group relative mt-[6px] rounded-full p-[4px] text-white transition-colors hover:text-brand-2"
        >
          <BellIcon className="h-[21px] w-[21px] transition-transform duration-300 group-hover:-rotate-12" />
          <span className="absolute right-[5px] top-[5px] h-[7px] w-[7px] rounded-full bg-brand-2 ring-2 ring-black" />
        </button>
      </header>

      {/* aperçu rapide */}
      <SectionLabel
        className="mt-[22px]"
        action={
          <button
            type="button"
            className="flex items-center gap-[1px] text-[11px] font-medium text-brand-2 transition-colors hover:text-white"
          >
            Tout voir
            <ChevronRight className="h-[11px] w-[11px]" />
          </button>
        }
      >
        Aperçu rapide
      </SectionLabel>

      <Card className="relative mt-[9px] overflow-hidden p-[16px]">
        <div className="pointer-events-none absolute -left-[14px] top-[6px] h-[140px] w-[140px] rounded-full bg-[radial-gradient(circle,rgba(79,140,255,0.30),transparent_68%)] blur-[6px]" />
        <div className="relative flex items-center gap-[14px]">
          <div className="relative shrink-0">
            <div className="absolute inset-0 rounded-full bg-brand/25 blur-[16px]" />
            <PlatinumBadge className="relative h-[108px] w-[108px] drop-shadow-[0_6px_18px_rgba(79,140,255,0.35)]" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[9px] font-semibold tracking-[0.16em] text-mut uppercase">
              Niveau
            </div>
            <div className="tnum -mt-[2px] text-[42px] font-bold leading-[1.05] tracking-[-0.03em] text-[#d7e3f8]">
              32
            </div>
            <div className="tnum mt-[6px] text-[13px] font-medium text-white">84%</div>
            <ProgressBar value={84} className="mt-[6px]" height={6} />
            <div className="mt-[7px] flex items-baseline justify-between">
              <span className="text-[10px] text-mut">Prochain niveau : 33</span>
              <span className="tnum text-[11px] font-semibold text-brand-2">89%</span>
            </div>
          </div>
        </div>
      </Card>

      {/* metals */}
      <Card className="mt-[12px] px-[6px] py-[18px]">
        <ul className="grid grid-cols-4">
          {metals.map((m, i) => (
            <li
              key={m.label}
              className="group flex flex-col items-center gap-[5px]"
              style={{ animationDelay: `${i * 60}ms` }}
            >
              <TrophyCup
                tone={m.tone}
                className="h-[30px] w-[30px] drop-shadow-[0_3px_8px_rgba(0,0,0,0.6)] transition-transform duration-300 group-hover:-translate-y-[2px]"
              />
              <span className="tnum text-[16px] font-bold leading-none text-white">
                {m.value}
              </span>
              <span className="text-[10px] leading-none text-mut">{m.label}</span>
            </li>
          ))}
        </ul>
      </Card>

      {/* progression globale */}
      <SectionLabel className="mt-[20px]">Progression globale</SectionLabel>
      <Card className="mt-[9px] flex items-center gap-[19px] p-[19px]">
        <Ring value={71} size={92} thickness={7.5} />
        <ul className="min-w-0 flex-1 space-y-[13px]">
          {globalRows.map((r) => (
            <li key={r.label}>
              <div className="text-[11px] leading-none text-mut">{r.label}</div>
              <div className="tnum mt-[4px] text-[15px] font-semibold leading-none text-white">
                {r.value}
                {r.muted && (
                  <span className="font-normal text-mut"> {r.muted}</span>
                )}
              </div>
            </li>
          ))}
        </ul>
      </Card>

      {/* récemment obtenus */}
      <SectionLabel
        className="mt-[20px]"
        action={
          <button
            type="button"
            className="flex items-center gap-[1px] text-[11px] font-medium text-brand-2 transition-colors hover:text-white"
          >
            Tout voir
            <ChevronRight className="h-[11px] w-[11px]" />
          </button>
        }
      >
        Récemment obtenus
      </SectionLabel>

      <Card className="mt-[9px] overflow-hidden">
        <ul className="divide-y divide-white/[0.05]">
          {recentTrophies.map((t) => (
            <li
              key={t.title}
              className="group flex cursor-pointer items-center gap-[13px] px-[11px] py-[14px] transition-colors hover:bg-white/[0.035]"
            >
              <span className="relative h-[48px] w-[48px] shrink-0 overflow-hidden rounded-full ring-1 ring-white/10">
                <img
                  src={t.tile}
                  alt=""
                  loading="lazy"
                  style={{ filter: t.tint === "none" ? undefined : t.tint }}
                  className="h-full w-full object-cover opacity-80 transition-transform duration-500 group-hover:scale-110"
                />
                <span className="absolute inset-0 rounded-full bg-[radial-gradient(circle_at_30%_25%,rgba(255,255,255,0.16),transparent_60%)]" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[12.5px] font-semibold leading-tight text-white">
                  {t.title}
                </span>
                <span className="mt-[2px] block truncate text-[11px] leading-tight text-mut-2">
                  {t.game}
                </span>
                <span className="mt-[2px] block text-[10px] leading-tight text-mut">
                  {t.when}
                </span>
              </span>
              <TrophyCup
                tone={t.tone}
                className="h-[30px] w-[30px] shrink-0 drop-shadow-[0_3px_8px_rgba(0,0,0,0.6)] transition-transform duration-300 group-hover:scale-110"
              />
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}
