import { useState } from "react";
import { PhoneFrame } from "./components/phone";
import { Reveal } from "./components/ui";
import { PlatinaLogo } from "./lib/icons";
import type { ScreenId } from "./lib/data";
import StatsScreen from "./screens/StatsScreen";
import GamesScreen from "./screens/GamesScreen";
import PlayScreen from "./screens/PlayScreen";
import SettingsScreen from "./screens/SettingsScreen";

const SCREENS: Record<ScreenId, () => React.JSX.Element> = {
  stats: StatsScreen,
  games: GamesScreen,
  play: PlayScreen,
  settings: SettingsScreen,
};

const CAPTIONS: { id: ScreenId; index: string; title: string; note: string }[] = [
  { id: "stats", index: "01", title: "Stats", note: "Niveau, trophées & progression" },
  { id: "games", index: "02", title: "Jeux", note: "En cours & platinés" },
  { id: "play", index: "03", title: "Play", note: "Temps de jeu & dépenses" },
  { id: "settings", index: "04", title: "Paramètres", note: "Compte & préférences" },
];

function ShowcasePhone({ initial }: { initial: ScreenId }) {
  const [screen, setScreen] = useState<ScreenId>(initial);
  const Active = SCREENS[screen];
  return (
    <PhoneFrame active={screen} onNavigate={setScreen}>
      <Active />
    </PhoneFrame>
  );
}

const NAV = [
  { label: "Stats", href: "#stats" },
  { label: "Jeux", href: "#jeux" },
  { label: "Play", href: "#play" },
  { label: "Paramètres", href: "#parametres" },
];

const HIGHLIGHTS = [
  { value: "1 456", label: "Trophées obtenus" },
  { value: "12", label: "Jeux platinés" },
  { value: "1 248 h", label: "Temps de jeu" },
  { value: "96", label: "Transactions" },
];

const FEATURES = [
  {
    title: "Synchronisation PSN",
    body: "Importe automatiquement trophées, progression et temps de jeu depuis ton compte PlayStation Network.",
  },
  {
    title: "Platinés en un coup d'œil",
    body: "Suis chaque jeu à 100 % avec des barres de progression détaillées par rareté de trophée.",
  },
  {
    title: "Dépenses PS Store",
    body: "Visualise ton budget, tes transactions et tes abonnements, présentés clairement.",
  },
  {
    title: "Design sombre soigné",
    body: "Une interface native, fluide et animée, pensée pour les longues sessions de nuit.",
  },
];

export default function App() {
  return (
    <div className="relative min-h-screen bg-black text-white">
      {/* ambient background */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 -z-10"
        style={{
          background:
            "radial-gradient(900px 520px at 18% -6%, rgba(47,107,255,0.20), transparent 60%), radial-gradient(820px 480px at 82% 4%, rgba(124,92,255,0.16), transparent 62%), radial-gradient(1000px 700px at 50% 108%, rgba(47,107,255,0.14), transparent 65%)",
        }}
      />
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 -z-10 opacity-[0.05]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.6) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.6) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
          maskImage:
            "radial-gradient(900px 600px at 50% 0%, black, transparent 75%)",
          WebkitMaskImage:
            "radial-gradient(900px 600px at 50% 0%, black, transparent 75%)",
        }}
      />

      {/* ---------------------------------------------------------- nav */}
      <header className="sticky top-0 z-50 border-b border-white/[0.06] bg-black/70 backdrop-blur-xl">
        <div className="mx-auto flex h-[62px] max-w-[1560px] items-center justify-between px-5 sm:px-8">
          <a href="#top" className="group flex items-center gap-[10px]">
            <PlatinaLogo className="h-[26px] w-[29px] transition-transform duration-500 group-hover:rotate-[-6deg]" />
            <span className="text-[19px] font-bold tracking-[-0.03em]">Platina</span>
          </a>
          <nav className="hidden items-center gap-8 md:flex">
            {NAV.map((n) => (
              <a
                key={n.label}
                href={n.href}
                className="relative text-[13.5px] font-medium text-mut-2 transition-colors hover:text-white"
              >
                {n.label}
              </a>
            ))}
          </nav>
          <a
            href="#apercu"
            className="rounded-full bg-brand px-[18px] py-[9px] text-[13px] font-semibold text-white shadow-[0_0_28px_-6px_rgba(47,107,255,0.95)] transition-all duration-300 hover:bg-brand-2 hover:shadow-[0_0_34px_-4px_rgba(79,140,255,1)]"
          >
            Télécharger
          </a>
        </div>
      </header>

      <main id="top">
        {/* ------------------------------------------------------ hero */}
        <section className="mx-auto max-w-[1560px] px-5 pt-14 pb-10 text-center sm:px-8 sm:pt-20">
          <Reveal>
            <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-[13px] py-[6px] text-[11.5px] font-medium text-mut-2">
              <span className="h-[6px] w-[6px] rounded-full bg-brand-2 shadow-[0_0_10px_2px_rgba(79,140,255,0.9)]" />
              PlayStation · iOS &amp; Android
            </span>
          </Reveal>
          <Reveal delay={80}>
            <h1 className="mx-auto mt-6 max-w-[15ch] text-[clamp(2.4rem,7vw,4.6rem)] font-extrabold leading-[1.02] tracking-[-0.045em]">
              Tes trophées,
              <br />
              <span className="bg-[linear-gradient(100deg,#8ec9ff,#4f8cff_45%,#7c5cff)] bg-clip-text text-transparent">
                ta légende.
              </span>
            </h1>
          </Reveal>
          <Reveal delay={160}>
            <p className="mx-auto mt-6 max-w-[54ch] text-[15px] leading-relaxed text-mut-2 sm:text-[16.5px]">
              Platina réunit tes platinés, ton temps de jeu et tes dépenses PS Store
              dans une interface sombre, rapide et magnifique — conçue pour les
              chasseurs de trophées.
            </p>
          </Reveal>
          <Reveal delay={240}>
            <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
              <a
                href="#apercu"
                className="rounded-full bg-white px-6 py-[13px] text-[14px] font-semibold text-black transition-transform duration-300 hover:-translate-y-[2px] hover:bg-white/90"
              >
                Voir l'application
              </a>
              <a
                href="#fonctions"
                className="rounded-full border border-white/12 bg-white/[0.03] px-6 py-[13px] text-[14px] font-semibold text-white transition-all duration-300 hover:-translate-y-[2px] hover:border-white/30 hover:bg-white/[0.07]"
              >
                Découvrir les fonctions
              </a>
            </div>
          </Reveal>
        </section>

        {/* --------------------------------------------------- showcase */}
        <section
          id="apercu"
          className="mx-auto max-w-[1560px] scroll-mt-20 px-5 pb-8 sm:px-8"
        >
          <Reveal>
            <div className="flex flex-wrap items-end justify-between gap-4 border-b border-white/[0.07] pb-5">
              <div>
                <span className="text-[10.5px] font-semibold tracking-[0.14em] text-mut uppercase">
                  Aperçu de l'application
                </span>
                <h2 className="mt-2 text-[22px] font-bold tracking-[-0.03em] sm:text-[26px]">
                  Quatre écrans, une seule obsession
                </h2>
              </div>
              <p className="max-w-[38ch] text-[13px] leading-relaxed text-mut">
                Touche la barre d'onglets de chaque appareil pour naviguer entre les
                écrans.{" "}
                <span className="text-brand-2 sm:hidden">
                  Fais glisser pour voir la suite →
                </span>
              </p>
            </div>
          </Reveal>

          <div className="no-bar -mx-5 mt-8 flex snap-x snap-mandatory gap-5 overflow-x-auto px-5 pb-6 sm:mx-0 sm:grid sm:grid-cols-2 sm:overflow-visible sm:px-0 lg:grid-cols-4 sm:gap-6 lg:gap-7">
            {CAPTIONS.map((c, i) => (
              <Reveal
                key={c.id}
                delay={i * 120}
                className="min-w-[80%] shrink-0 snap-center sm:min-w-0"
              >
                <figure id={c.id} className="group scroll-mt-20">
                  <div className="relative">
                    <div
                      aria-hidden
                      className="pointer-events-none absolute inset-x-6 bottom-4 top-10 -z-10 rounded-[60px] bg-brand/25 opacity-60 blur-[46px] transition-opacity duration-500 group-hover:opacity-100"
                    />
                    <div className="transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:-translate-y-2">
                      <ShowcasePhone initial={c.id} />
                    </div>
                  </div>
                  <figcaption className="mt-5 flex items-baseline gap-3 px-1">
                    <span className="tnum text-[11px] font-semibold text-brand-2">
                      {c.index}
                    </span>
                    <span className="min-w-0">
                      <span className="block text-[14px] font-semibold tracking-[-0.01em]">
                        {c.title}
                      </span>
                      <span className="block text-[12px] text-mut">{c.note}</span>
                    </span>
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        </section>

        {/* ------------------------------------------------- highlights */}
        <section className="mx-auto max-w-[1560px] px-5 py-14 sm:px-8">
          <Reveal>
            <ul className="grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-white/[0.07] bg-white/[0.06] md:grid-cols-4">
              {HIGHLIGHTS.map((h) => (
                <li
                  key={h.label}
                  className="group bg-[#07090d] px-5 py-7 text-center transition-colors duration-300 hover:bg-[#0b0f16]"
                >
                  <div className="tnum text-[clamp(1.5rem,3.4vw,2.2rem)] font-extrabold tracking-[-0.03em] text-white transition-colors duration-300 group-hover:text-brand-2">
                    {h.value}
                  </div>
                  <div className="mt-2 text-[12px] tracking-[0.04em] text-mut uppercase">
                    {h.label}
                  </div>
                </li>
              ))}
            </ul>
          </Reveal>
        </section>

        {/* --------------------------------------------------- features */}
        <section id="fonctions" className="mx-auto max-w-[1560px] scroll-mt-20 px-5 pb-20 sm:px-8">
          <Reveal>
            <div className="max-w-[52ch]">
              <span className="text-[10.5px] font-semibold tracking-[0.14em] text-mut uppercase">
                Fonctions
              </span>
              <h2 className="mt-3 text-[clamp(1.6rem,3.6vw,2.4rem)] font-extrabold leading-tight tracking-[-0.035em]">
                Tout ce qu'un chasseur de trophées attend
              </h2>
            </div>
          </Reveal>
          <ul className="mt-9 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {FEATURES.map((f, i) => (
              <Reveal key={f.title} delay={i * 90} as="li">
                  <div className="group h-full rounded-2xl border border-white/[0.07] bg-gradient-to-b from-[#0b0f16] to-[#070a0f] p-6 transition-all duration-300 hover:-translate-y-1 hover:border-brand/40 hover:shadow-[0_24px_60px_-30px_rgba(47,107,255,0.9)]">
                  <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-brand/30 bg-brand/15 text-[13px] font-bold text-brand-2">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <h3 className="mt-5 text-[16px] font-semibold tracking-[-0.01em]">
                    {f.title}
                  </h3>
                  <p className="mt-2.5 text-[13.5px] leading-relaxed text-mut">
                    {f.body}
                  </p>
                </div>
              </Reveal>
            ))}
          </ul>
        </section>

        {/* ------------------------------------------------------- cta */}
        <section className="mx-auto max-w-[1560px] px-5 pb-24 sm:px-8">
          <Reveal>
            <div className="relative overflow-hidden rounded-[28px] border border-white/[0.08] bg-[linear-gradient(140deg,#0b1220,#070a10_55%,#0d0a1c)] px-6 py-14 text-center sm:px-12">
              <div
                aria-hidden
                className="pointer-events-none absolute inset-0 opacity-70"
                style={{
                  background:
                    "radial-gradient(600px 260px at 50% 0%, rgba(47,107,255,0.30), transparent 65%)",
                }}
              />
              <div className="relative">
                <PlatinaLogo className="mx-auto h-10 w-11" />
                <h2 className="mx-auto mt-6 max-w-[24ch] text-[clamp(1.7rem,4vw,2.6rem)] font-extrabold leading-tight tracking-[-0.04em]">
                  Prêt à faire briller ta collection ?
                </h2>
                <p className="mx-auto mt-4 max-w-[46ch] text-[14.5px] leading-relaxed text-mut-2">
                  Rejoins les chasseurs de platine qui suivent chaque trophée avec
                  Platina. Gratuit, sans publicité.
                </p>
                <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
                  <a
                    href="#apercu"
                    className="rounded-full bg-brand px-7 py-[13px] text-[14px] font-semibold shadow-[0_0_30px_-6px_rgba(47,107,255,1)] transition-all duration-300 hover:-translate-y-[2px] hover:bg-brand-2"
                  >
                    Télécharger Platina
                  </a>
                  <a
                    href="#parametres"
                    className="rounded-full border border-white/12 px-7 py-[13px] text-[14px] font-semibold text-white transition-all duration-300 hover:-translate-y-[2px] hover:border-white/30 hover:bg-white/[0.06]"
                  >
                    Voir les paramètres
                  </a>
                </div>
              </div>
            </div>
          </Reveal>
        </section>
      </main>

      {/* ------------------------------------------------------ footer */}
      <footer className="border-t border-white/[0.07] bg-black">
        <div className="mx-auto flex max-w-[1560px] flex-col gap-6 px-5 py-10 sm:flex-row sm:items-center sm:justify-between sm:px-8">
          <div className="flex items-center gap-[10px]">
            <PlatinaLogo className="h-[22px] w-[25px]" />
            <span className="text-[15px] font-bold tracking-[-0.02em]">Platina</span>
            <span className="ml-2 text-[12px] text-mut">Version 1.0.0</span>
          </div>
          <p className="max-w-[60ch] text-[12px] leading-relaxed text-mut">
            Concept d'interface. PlayStation, PS Store et PlayStation Plus sont des
            marques de Sony Interactive Entertainment. Projet de démonstration sans
            affiliation.
          </p>
          <div className="flex items-center gap-5 text-[12.5px] text-mut-2">
            {["Support", "Confidentialité", "Conditions"].map((l) => (
              <a key={l} href="#top" className="transition-colors hover:text-white">
                {l}
              </a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
