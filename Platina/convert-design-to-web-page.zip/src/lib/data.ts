export type Tone = "plat" | "gold" | "silver" | "bronze";

export type Game = {
  id: string;
  title: string;
  platform: "PS5" | "PS4";
  progress: number;
  cover: string;
  tone: "blue" | "violet";
  counts: [number, number, number, number]; // plat, gold, silver, bronze
  date?: string;
};

export const currentGames: Game[] = [
  {
    id: "elden",
    title: "Elden Ring",
    platform: "PS5",
    progress: 62,
    cover: "/images/g-elden.jpg",
    tone: "blue",
    counts: [0, 2, 8, 24],
  },
  {
    id: "ghost",
    title: "Ghost of Tsushima",
    platform: "PS5",
    progress: 45,
    cover: "/images/g-ghost.jpg",
    tone: "blue",
    counts: [0, 1, 6, 27],
  },
  {
    id: "rdr",
    title: "Red Dead Redemption 2",
    platform: "PS4",
    progress: 33,
    cover: "/images/g-rdr.jpg",
    tone: "blue",
    counts: [0, 1, 2, 15],
  },
  {
    id: "hogwarts",
    title: "Hogwarts Legacy",
    platform: "PS5",
    progress: 28,
    cover: "/images/g-hogwarts.jpg",
    tone: "blue",
    counts: [0, 0, 4, 20],
  },
];

export const platinized: Game[] = [
  {
    id: "gow",
    title: "God of War Ragnarök",
    platform: "PS5",
    progress: 100,
    cover: "/images/g-gow.jpg",
    tone: "violet",
    counts: [1, 4, 15, 16],
    date: "12/05/2024",
  },
  {
    id: "spider",
    title: "Marvel's Spider-Man 2",
    platform: "PS5",
    progress: 100,
    cover: "/images/g-spider.jpg",
    tone: "violet",
    counts: [1, 2, 17, 22],
    date: "28/04/2024",
  },
  {
    id: "tlou",
    title: "The Last of Us Part II",
    platform: "PS4",
    progress: 100,
    cover: "/images/g-tlou.jpg",
    tone: "violet",
    counts: [1, 4, 10, 21],
    date: "14/03/2024",
  },
];

export const recentTrophies: {
  title: string;
  game: string;
  when: string;
  tile: string;
  tone: Tone;
  tint: string;
}[] = [
  {
    title: "Le voyage commence",
    game: "Horizon Zero Dawn",
    when: "Il y a 2 heures",
    tile: "/images/trophy-tile.jpg",
    tone: "plat",
    tint: "none",
  },
  {
    title: "Maître d'armes",
    game: "God of War Ragnarök",
    when: "Il y a 1 jour",
    tile: "/images/trophy-tile.jpg",
    tone: "gold",
    tint: "hue-rotate(-152deg) saturate(1.35) brightness(0.95)",
  },
  {
    title: "Rookie",
    game: "Rocket League",
    when: "Il y a 2 jours",
    tile: "/images/trophy-tile.jpg",
    tone: "bronze",
    tint: "hue-rotate(-118deg) saturate(0.95) brightness(1.05)",
  },
];

export const weeklyHours = [
  { day: "Lun", value: 3.4 },
  { day: "Mar", value: 6.6 },
  { day: "Mer", value: 5.2 },
  { day: "Jeu", value: 4.6 },
  { day: "Ven", value: 7.6 },
  { day: "Sam", value: 5.8 },
  { day: "Dim", value: 6.5 },
];

export const settingsGroups: {
  label: string;
  rows: {
    icon: "users" | "link" | "lock" | "bell" | "palette" | "globe" | "currency" | "appearance" | "upload" | "save" | "info" | "mail";
    title: string;
    sub: string;
    value?: string;
  }[];
}[] = [
  {
    label: "Compte",
    rows: [
      {
        icon: "users",
        title: "Compte & Synchronisation",
        sub: "Gère ton compte et tes données",
      },
      {
        icon: "link",
        title: "Comptes liés",
        sub: "PlayStation Network, Twitch, Discord",
      },
      {
        icon: "lock",
        title: "Confidentialité",
        sub: "Gère tes informations personnelles",
      },
    ],
  },
  {
    label: "Préférences",
    rows: [
      {
        icon: "bell",
        title: "Notifications",
        sub: "Gérer les alertes et rappels",
      },
      { icon: "palette", title: "Theme", sub: "", value: "Sombre" },
      { icon: "globe", title: "Langue", sub: "", value: "Français" },
      { icon: "currency", title: "Devise", sub: "", value: "Euro (€)" },
      { icon: "appearance", title: "Apparence", sub: "" },
    ],
  },
  {
    label: "Données",
    rows: [
      {
        icon: "upload",
        title: "Importer ses trophées",
        sub: "Depuis PlayStation Network",
      },
      {
        icon: "save",
        title: "Sauvegarde & Données",
        sub: "Sauvegarder ou restaurer tes données",
      },
    ],
  },
  {
    label: "À propos",
    rows: [
      { icon: "info", title: "À propos de Platina", sub: "Version 1.0.0" },
      { icon: "mail", title: "Nous contacter", sub: "Support & FAQ" },
    ],
  },
];

export type ScreenId = "stats" | "games" | "play" | "settings";
